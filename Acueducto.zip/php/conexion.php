<?php 

function conexion(){
	 $servidor="172.17.0.1:3306";
	 $usuario="root";
	 $bd="acueducto";
	 $password="19921616";

	$conexion=mysqli_connect($servidor,$usuario,$password,$bd) or die(mysqli_error($conexion));

	return $conexion;
} 
	
?>
